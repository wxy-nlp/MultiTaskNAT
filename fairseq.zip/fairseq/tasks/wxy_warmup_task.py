import torch
from fairseq.tasks import register_task
from fairseq.tasks.translation_lev import TranslationLevenshteinTask, TranslationLevenshteinConfig


@register_task("wxy_warmup_task", dataclass=TranslationLevenshteinConfig)
class wxy_warmup_task(TranslationLevenshteinTask):
    """
    My warm-up task, just for verifying the power of this work:
    <Multi-Task Learning with Shared Encoder for Non-Autoregressive Machine Translation>
    """
    def train_step(
            self, sample, model, criterion, optimizer, update_num, ignore_grad=False
    ):
        model.train()
        sample["prev_target"] = self.inject_noise(sample["target"])
        loss, sample_size, logging_output = criterion(model, sample)
        if ignore_grad:
            loss *= 0
        optimizer.backward(loss)
        return loss, sample_size, logging_output
