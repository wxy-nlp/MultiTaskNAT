# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import os
from copy import deepcopy
import logging

import torch

from dataclasses import dataclass, field
from fairseq.tasks import register_task
from fairseq.tasks.translation import TranslationTask, load_langpair_dataset
from fairseq.tasks.translation_lev import TranslationLevenshteinTask, TranslationLevenshteinConfig
from fairseq.utils import new_arange
from fairseq.data.dictionary import Dictionary

EVAL_BLEU_ORDER = 4
logger = logging.getLogger(__name__)

@dataclass
class NATCTCConfig(TranslationLevenshteinConfig):
    upsample_scale: int = field(
        default=3, metadata={"help": "the amount of src_tokens upsample scale."}
    )

class MyDictionary(Dictionary):
    def __init__(
            self,
            *,  # begin keyword-only arguments
            bos="<s>",
            pad="<pad>",
            eos="</s>",
            unk="<unk>",
            blank="<_>",
            extra_special_symbols=None,
    ):
        self.bos_word, self.unk_word, self.pad_word, self.eos_word = bos, unk, pad, eos
        self.blank_word = blank
        self.blank_index = -1
        self.symbols = []
        self.count = []
        self.indices = {}
        self.bos_index = self.add_symbol(bos)
        self.pad_index = self.add_symbol(pad)
        self.eos_index = self.add_symbol(eos)
        self.unk_index = self.add_symbol(unk)
        if extra_special_symbols:
            for s in extra_special_symbols:
                self.add_symbol(s)
        self.nspecial = len(self.symbols)

    @classmethod
    def load(cls, f):
        """Loads the dictionary from a text file with the format:

        ```
        <symbol0> <count0>
        <symbol1> <count1>
        ...
        ```
        """
        d = cls()
        d.add_from_file(f)
        d.blank_index = d.add_symbol(d.blank_word)
        return d

@register_task('mt_ctc_task', dataclass=NATCTCConfig)
class MT_CTC_Task(TranslationLevenshteinTask):

    def train_step(self,
                   sample,
                   model,
                   criterion,
                   optimizer,
                   update_num,
                   ignore_grad=False):
        model.train()
        at_sample = deepcopy(sample)
        nat_sample = sample
        src_tokens = sample["net_input"]["src_tokens"].clone()
        bsz, src_len = src_tokens.size(0), src_tokens.size(1)
        upsample_src_tokens = torch.zeros([bsz, src_len * self.cfg.upsample_scale]).\
            fill_(self.src_dict.unk()).type_as(src_tokens)
        nat_sample['prev_target'] = upsample_src_tokens
        loss, sample_size, logging_output = criterion(model, at_sample, nat_sample, None)
        if ignore_grad:
            loss *= 0
        optimizer.backward(loss)
        return loss, sample_size, logging_output

    def valid_step(self, sample, model, criterion):
        model.eval()
        with torch.no_grad():
            at_sample = deepcopy(sample)
            nat_sample = sample
            src_tokens = sample["net_input"]["src_tokens"].clone()
            bsz, src_len = src_tokens.size(0), src_tokens.size(1)
            upsample_src_tokens = torch.zeros([bsz, src_len * self.cfg.upsample_scale]). \
                fill_(self.src_dict.unk()).type_as(src_tokens)
            nat_sample['prev_target'] = upsample_src_tokens
            loss, sample_size, logging_output = criterion(model, at_sample, nat_sample)
            # 以下为后来添加
            if self.cfg.eval_bleu:
                bleu = self._inference_with_bleu(self.sequence_generator, sample, model)
                logging_output["_bleu_sys_len"] = bleu.sys_len
                logging_output["_bleu_ref_len"] = bleu.ref_len
                # we split counts into separate entries so that they can be
                # summed efficiently across workers using fast-stat-sync
                assert len(bleu.counts) == EVAL_BLEU_ORDER
                for i in range(EVAL_BLEU_ORDER):
                    logging_output["_bleu_counts_" + str(i)] = bleu.counts[i]
                    logging_output["_bleu_totals_" + str(i)] = bleu.totals[i]
        return loss, sample_size, logging_output

    def build_generator(self, models, args, **unused):
        # add models input to match the API for SequenceGenerator
        from fairseq.iterative_refinement_generator import IterativeRefinementGenerator

        return IterativeRefinementGenerator(
            self.target_dictionary,
            eos_penalty=getattr(args, "iter_decode_eos_penalty", 0.0),
            max_iter=getattr(args, "iter_decode_max_iter", 0),
            beam_size=getattr(args, "iter_decode_with_beam", 1),
            reranking=getattr(args, "iter_decode_with_external_reranker", False),
            decoding_format=getattr(args, "decoding_format", None),
            adaptive=not getattr(args, "iter_decode_force_max_iter", True),
            retain_history=getattr(args, "retain_iter_history", False),
        )

    @classmethod
    def load_dictionary(cls, filename):
        """Load the dictionary from the filename

        Args:
            filename (str): the filename
        """
        return MyDictionary.load(filename)

    def filter_indices_by_size(
            self,
            indices,
            dataset,
            max_positions=None,
            ignore_invalid_inputs=False,
    ):
        """
        Filter examples that are too large

        Args:
            indices (np.array): original array of sample indices
            dataset (~fairseq.data.FairseqDataset): dataset to batch
            max_positions (optional): max sentence length supported by the
                model (default: None).
            ignore_invalid_inputs (bool, optional): don't raise Exception for
                sentences that are too long (default: False).
        Returns:
            np.array: array of filtered sample indices
        """
        original_size = len(indices)
        if ignore_invalid_inputs and hasattr(self.cfg, "upsample_scale"):
            max_positions = (
                # (dataset.tgt_sizes[indices] * self.cfg.upsample_scale).tolist(),
                (dataset.src_sizes[indices]).tolist(),
                (dataset.src_sizes[indices] * self.cfg.upsample_scale).tolist(),
            )
        indices, ignored = dataset.filter_indices_by_size(indices, max_positions)
        if len(ignored) > 0:
            if not ignore_invalid_inputs:
                raise Exception((
                                    'Size of sample #{} is invalid (={}) since max_positions={}, '
                                    'skip this example with --skip-invalid-size-inputs-valid-test'
                                ).format(ignored[0], dataset.size(ignored[0]), max_positions))
            if hasattr(self.cfg, "upsample_scale"):
                logger.warning((
                                   'when ctc loss enabled, {} samples have invalid sizes and will be skipped, '
                                   'where the src_len * {} < tgt_len'
                               ).format(len(ignored), self.cfg.upsample_scale))
            else:
                logger.warning((
                                   '{} samples have invalid sizes and will be skipped, '
                                   'max_positions={}, first few sample ids={}'
                               ).format(len(ignored), max_positions, ignored[:10]))

            logger.info(f"Dataset original size: {original_size}, filtered size: {len(indices)}")

        return indices


