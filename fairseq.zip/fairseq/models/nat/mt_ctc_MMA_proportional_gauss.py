import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from fairseq.iterative_refinement_generator import DecoderOut
from fairseq.models import register_model, register_model_architecture
from fairseq.models.nat import FairseqNATDecoder, FairseqNATModel, ensemble_decoder
from fairseq.models.transformer import Embedding, TransformerDecoder, TransformerModel
from fairseq.modules.transformer_layer import TransformerDecoderLayer
from fairseq.modules import LayerNorm, MultiheadAttention
from fairseq.models.nat.nonautoregressive_transformer import NATransformerModel, NATransformerDecoder
from fairseq.models.nat.nat_ctc_6_up_6 import NAT_ctc_6_up_6_model, NAT_ctc_encoder, NAT_ctc_decoder
from fairseq.models.fairseq_incremental_decoder import FairseqIncrementalDecoder
from examples.simultaneous_translation.modules.monotonic_multihead_attention \
    import MonotonicAttention
from examples.simultaneous_translation.utils.functions import exclusive_cumprod


class TransformerMonotonicDecoder_Pro(TransformerDecoder):
    """
    Transformer decoder consisting of *args.decoder_layers* layers. Each layer
    is a :class:`TransformerDecoderLayer`.

    Args:
        args (argparse.Namespace): parsed command-line arguments
        dictionary (~fairseq.data.Dictionary): decoding dictionary
        embed_tokens (torch.nn.Embedding): output embedding
        no_encoder_attn (bool, optional): whether to attend to encoder outputs
            (default: False).
    """

    def __init__(self, args, dictionary, embed_tokens, no_encoder_attn=False):
        super().__init__(args, dictionary, embed_tokens, no_encoder_attn=False)

        self.dictionary = dictionary
        self.layers = nn.ModuleList([])
        self.layers.extend(
            [
                MMA_Pro_DecoderLayer(args, no_encoder_attn)
                for _ in range(args.shallow_at_decoder_layers)
            ]
        )

    def pre_attention(
        self, prev_output_tokens, encoder_out_dict, incremental_state=None
    ):
        positions = (
            self.embed_positions(
                prev_output_tokens,
                incremental_state=incremental_state,
            )
            if self.embed_positions is not None
            else None
        )

        if incremental_state is not None:
            prev_output_tokens = prev_output_tokens[:, -1:]
            if positions is not None:
                positions = positions[:, -1:]

        # embed tokens and positions
        x = self.embed_scale * self.embed_tokens(prev_output_tokens)

        if self.project_in_dim is not None:
            x = self.project_in_dim(x)

        if positions is not None:
            x += positions

        x = self.dropout_module(x)

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        encoder_out = encoder_out_dict["encoder_out"][0]
        encoder_padding_mask = (
            encoder_out_dict["encoder_padding_mask"][0]
            if len(encoder_out_dict["encoder_padding_mask"]) > 0
            else None
        )

        return x, encoder_out, encoder_padding_mask

    def post_attention(self, x):
        if self.layer_norm:
            x = self.layer_norm(x)

        # T x B x C -> B x T x C
        x = x.transpose(0, 1)

        if self.project_out_dim is not None:
            x = self.project_out_dim(x)

        return x

    def extract_features(
        self, prev_output_tokens, encoder_out, incremental_state=None, **unused
    ):
        """
        Similar to *forward* but only return features.

        Returns:
            tuple:
                - the decoder's features of shape `(batch, tgt_len, embed_dim)`
                - a dictionary with any model-specific outputs
        """
        (x, encoder_outs, encoder_padding_mask) = self.pre_attention(
            prev_output_tokens, encoder_out, incremental_state
        )
        attn = None
        inner_states = [x]
        attn_list = []

        for i, layer in enumerate(self.layers):

            x, attn, _ = layer(
                x=x,
                encoder_out=encoder_outs,
                encoder_padding_mask=encoder_padding_mask,
                incremental_state=incremental_state,
                self_attn_mask=self.buffered_future_mask(x)
                if incremental_state is None
                else None,
            )

            inner_states.append(x)
            attn_list.append(attn)

        x = self.post_attention(x)

        return x, {
            "action": 1,
            "attn_list": attn_list,
            "encoder_out": encoder_out,
            "encoder_padding_mask": encoder_padding_mask,
        }


class MMA_Pro_DecoderLayer(TransformerDecoderLayer):
    def __init__(
        self, args, no_encoder_attn=False, add_bias_kv=False, add_zero_attn=False
    ):
        super().__init__(
            args,
            no_encoder_attn=True,
            add_bias_kv=add_bias_kv,
            add_zero_attn=add_zero_attn,
        )

        self.encoder_attn = MonotonicMultiheadAttention_Proportional_Gauss(args)
        self.encoder_attn_layer_norm = LayerNorm(
            self.embed_dim, export=getattr(args, "char_inputs", False)
        )


class MonotonicMultiheadAttention_Proportional_Gauss(MultiheadAttention):
    def __init__(self, args):
        super().__init__(
            embed_dim=args.decoder_embed_dim,
            num_heads=args.decoder_attention_heads,
            kdim=getattr(args, "encoder_embed_dim", None),
            vdim=getattr(args, "encoder_embed_dim", None),
            dropout=args.attention_dropout,
            encoder_decoder_attention=True,
        )

        self.k_in_proj = {"monotonic": self.k_proj}
        self.q_in_proj = {"monotonic": self.q_proj}
        self.v_in_proj = {"output": self.v_proj}

        self.sigma = args.gauss_sigma

    def v_proj_output(self, value):
        bsz = value.size(1)
        v = self.v_in_proj["output"](value)
        v_proj = v.contiguous().view(
            -1, bsz * self.num_heads, self.head_dim
        ).transpose(0, 1)
        return v_proj

    def normfun(self, x, mu):
        pdf = torch.exp(-((x - mu) ** 2) / (2 * self.sigma ** 2)) / (self.sigma * np.sqrt(2 * np.pi))
        return pdf

    def build_attn_weights(self, query, key, key_padding_mask):
        tgt_len, bsz, embed_dim = query.size()
        src_len = key.size(0)
        aranges = torch.arange(src_len).expand(tgt_len, -1).expand(bsz*self.num_heads, -1, -1).type_as(query)
        # key_padding_mask: bsz * num_heads, src_len
        key_padding_mask = key_padding_mask.clone().unsqueeze(1).expand(-1, self.num_heads, -1).\
            reshape(bsz * self.num_heads, -1)
        src_len_without_padding = torch.sum(~key_padding_mask, dim=1)

        attn_list = []
        for i in range(0, tgt_len):
            attn_i = aranges[:, i].clone()
            src_attend_position = i * src_len_without_padding / tgt_len
            src_attend_position = src_attend_position.trunc().long()

            # x = torch.arange(src_len).expand(bsz_num_heads, -1)
            mu = src_attend_position.unsqueeze(1)
            attn_i = self.normfun(attn_i, mu).type_as(attn_i)
            attn_list.append(attn_i.unsqueeze(1))

        attn_weights = torch.cat(attn_list[0:], dim=1)

        if torch.isnan(attn_weights).any():
            # Something is wrong
            raise RuntimeError("NaN in attn_weights.")

        return attn_weights

    def forward(
            self, query, key, value,
            key_padding_mask=None, attn_mask=None, incremental_state=None,
            need_weights=True, static_kv=False, *args, **kwargs
    ):
        tgt_len, bsz, embed_dim = query.size()
        src_len = value.size(0)

        # bsz * self.num_heads, tgt_len, src_len
        attn_weights = self.build_attn_weights(query, key, key_padding_mask)

        v_proj = self.v_proj_output(value)

        attn = torch.bmm(attn_weights.type_as(v_proj), v_proj)

        attn = attn.transpose(0, 1).contiguous().view(tgt_len, bsz, embed_dim)

        attn = self.out_proj(attn)

        return attn, \
               {"attn_weights": attn_weights }


class hybrid_decoder(NAT_ctc_decoder):
    def __init__(self, args, dictionary, embed_tokens, at_decoder, nat_decoder=None):
        super().__init__(args, dictionary, embed_tokens)
        self.at_decoder = at_decoder
        # self.nat_decoder = nat_decoder


@register_model("mt_ctc_MMA_pro_gauss")
class mt_ctc_mma_pro_gauss_model(NAT_ctc_6_up_6_model):
    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        # nat_decoder = NATransformerModel.build_decoder(args, tgt_dict, embed_tokens)
        at_decoder = TransformerMonotonicDecoder_Pro(args, tgt_dict, embed_tokens)
        return hybrid_decoder(args, tgt_dict, embed_tokens, at_decoder)

    @staticmethod
    def add_args(parser):
        NAT_ctc_6_up_6_model.add_args(parser)
        parser.add_argument("--shallow-at-decoder-layers", type=int, metavar='N',
                            help="the number of at decoder.")
        parser.add_argument("--gauss-sigma", type=float, metavar='D', default=1,
                            help="the sigma of the monotonic attention with gauss in AT decoder.")


    def forward(self, at_src_tokens, nat_src_tokens, src_lengths, prev_nat, prev_at, tgt_tokens, **kwargs):
        # 执行两次模型。at_src_tokens和nat_src_tokens的区别就在于顺序不同
        nat_encoder_out = self.encoder(nat_src_tokens, src_lengths=src_lengths, **kwargs)
        at_encoder_out = self.encoder(at_src_tokens, src_lengths=src_lengths, **kwargs)

        nat_decode_output = self.decoder(nat_encoder_out,
                                         prev_nat,
                                         normalize=False,
                                         features_only=False)

        at_decode_output = self.decoder(at_encoder_out,
                                        prev_nat,
                                        normalize=False,
                                        features_only=True)

        at_monotonic_encode_output = {
            "encoder_out": [at_decode_output],
            "encoder_padding_mask": [at_encoder_out["upsample_mask"]]
        }

        # AT shallow decoding
        at_monotonic_decode_output, _ = self.decoder.at_decoder(prev_at,
                                                      encoder_out=at_monotonic_encode_output,
                                                      features_only=False,
                                                      return_all_hiddens=True)

        return ({
                    "out": nat_decode_output, # T x B x C
                    "name": "NAT"
                },
                {
                    "out": at_monotonic_decode_output, # B x T x C
                    "name": "AT"
                }
        )


@register_model_architecture("mt_ctc_MMA_pro_gauss", "mt_ctc_MMA_pro_gauss")
def base_architecture(args):
    # This is actually nat_ctc_decoder.
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 6)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.upsample_scale = getattr(args, "upsample_scale", 3)
    args.shallow_at_decoder_layers = getattr(args, "shallow_at_decoder_layers", 1)

    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", False)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.no_cross_attention = getattr(args, "no_cross_attention", False)
    args.cross_self_attention = getattr(args, "cross_self_attention", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    args.tie_adaptive_weights = getattr(args, "tie_adaptive_weights", False)
    args.checkpoint_activations = getattr(args, "checkpoint_activations", False)
    args.offload_activations = getattr(args, "offload_activations", False)
    if args.offload_activations:
        args.checkpoint_activations = True
    args.encoder_layers_to_keep = getattr(args, "encoder_layers_to_keep", None)
    args.decoder_layers_to_keep = getattr(args, "decoder_layers_to_keep", None)
    args.encoder_layerdrop = getattr(args, "encoder_layerdrop", 0)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.quant_noise_pq_block_size = getattr(args, "quant_noise_pq_block_size", 8)
    args.quant_noise_scalar = getattr(args, "quant_noise_scalar", 0)
