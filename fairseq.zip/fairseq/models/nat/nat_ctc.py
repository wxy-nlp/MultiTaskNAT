import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from fairseq import utils
from fairseq.iterative_refinement_generator import DecoderOut
from fairseq.models import register_model, register_model_architecture
from fairseq.models.fairseq_encoder import FairseqEncoder
from fairseq.models.fairseq_decoder import FairseqDecoder
from fairseq.models.nat import FairseqNATDecoder, FairseqNATModel, ensemble_decoder
from fairseq.models.transformer import Embedding, TransformerDecoder, TransformerModel, TransformerEncoder
from fairseq.models.nat.nonautoregressive_transformer import NATransformerModel, NATransformerDecoder
from fairseq.modules.transformer_layer import TransformerEncoderLayer
from fairseq.models.fairseq_incremental_decoder import FairseqIncrementalDecoder
from typing import Any, Dict, List, Optional, Tuple
from fairseq.modules import (
    AdaptiveSoftmax,
    FairseqDropout,
    LayerDropModuleList,
    LayerNorm,
    PositionalEmbedding,
    SinusoidalPositionalEmbedding,
    TransformerDecoderLayer,
    TransformerEncoderLayer,
)


# 为了使用Transformer的build_model, get_normalized_probs,
# 再加上本身属于NAT model, 所以选择FairseqNATModel为父类
@register_model("nat_ctc")
class NAT_ctc_model(FairseqNATModel):
    def __init__(self, args, encoder, decoder):
        super().__init__(args, encoder, decoder)
        self.scale = args.upsample_scale
        self.blank_idx = decoder.dictionary.blank_index

    @staticmethod
    def add_args(parser):
        FairseqNATModel.add_args(parser)
        parser.add_argument("--upsample-scale", type=int, metavar='N',
                            help="the upsample scale of src-token-embedding.")

    @classmethod
    def build_encoder(cls, args, src_dict, encoder_embed_tokens):
        """
        The encoder implements upsampling.
        """
        return NAT_ctc_encoder(args, src_dict, encoder_embed_tokens)

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        """
        The decoder is actually TransformerEncoder.
        """
        return NAT_ctc_decoder(args, tgt_dict, embed_tokens)

    def forward(self, src_tokens, src_lengths, prev_output_tokens):
        upsample_x, upsample_mask = self.encoder(src_tokens, src_lengths)
        output = self.decoder(upsample_x, upsample_mask, normalize=False)
        return output

    '''
    def initialize_output_tokens(self, encoder_out, src_tokens):
        # 不能像之前一样简单粗暴地用unk，因为本模型没有encoder，
        # 所以应该要把待翻译的src句子embed+upsample之后的结果返回
        # encoder_out为(upsample_x, upsample_mask)
        initial_output_tokens = src_tokens.unsqueeze(-1).expand(-1, -1, self.scale).reshape(batch_size, -1)
        initial_output_scores = initial_output_tokens.new_zeros(
            *initial_output_tokens.size()
        ).type_as(initial_output_tokens)
        
        # We just use encoder_out at forward_decoder and dont use output_tokens and output_scores.
        # Usually use encoder_out to predict length, and create initial_output_tokens
        # with length predicted. but in NAT_CTC model we dont need to predict length, 
        # so we write this function just for matching iterative_refinement_generator.
        return DecoderOut(
            output_tokens=initial_output_tokens,
            output_scores=initial_output_scores,
            attn=None,
            step=0,
            max_step=0,
            history=None,
        )
    '''

    def initialize_output_tokens(self, encoder_out, src_tokens):
        upsample_x, _ = encoder_out
        initial_output_tokens = src_tokens.new_zeros(
            src_tokens.size(0), src_tokens.size(1) * self.scale
        ).fill_(self.pad)
        initial_output_scores = initial_output_tokens.new_zeros(
            *initial_output_tokens.size()
        ).type_as(upsample_x)
        return DecoderOut(
            output_tokens=initial_output_tokens,
            output_scores=initial_output_scores,
            attn=None,
            step=0,
            max_step=0,
            history=None,
        )

    '''
    def forward_decoder(self, decoder_out, encoder_out, **kwargs):
        # 包含了upsample_x和upsample_mask
        upsample_x, upsample_mask = encoder_out
        step = decoder_out.step
        history = decoder_out.history

        # execute the decoder
        # 由于需要适配ctc_loss函数，返回的output.shape=T x B x C
        # 所以先变为B x T x C
        # 并且这里选择直接将normalize设置为True，即直接进行log_softmax操作
        _scores, _tokens = self.decoder(
            upsample_x=upsample_x,
            upsample_mask=upsample_mask,
            normalize=True
        ).transpose(0, 1).max(-1)

        # greedy decoding
        max_length = _tokens.size(-1)
        outputs = []
        scores = []
        for i, sentence in enumerate(_tokens):
            idx = [False] * max_length
            prev_token = None
            for j, token in enumerate(sentence):
                if token == self.blank_idx:
                    prev_token = None
                elif prev_token == None:
                    prev_token = token
                    idx[j] = True
                elif token == prev_token:
                    continue
                else:
                    idx[j] = True
                    prev_token = token
            output = sentence[idx].tolist()
            score = _scores[i][idx].tolist()
            token_pad_list = [self.pad] * (max_length - len(output))
            score_pad_list = [0.0] * (max_length - len(output))
            output = torch.tensor(output + token_pad_list).type_as(_tokens).unsqueeze(0)
            score = torch.tensor(score + score_pad_list).type_as(_scores).unsqueeze(0)
            if i == 0:
                outputs = output
                scores = score
            else:
                outputs = torch.cat((outputs, output), dim=0)
                scores = torch.cat((scores, score), dim=0)

        return decoder_out._replace(
            output_tokens=outputs,
            output_scores=scores,
            attn=None,
            history=history,
        )
    '''

    def forward_decoder(self, decoder_out, encoder_out, **kwargs):
        # 包含了upsample_x和upsample_mask
        upsample_x, upsample_mask = encoder_out
        history = decoder_out.history
        output_tokens = decoder_out.output_tokens
        output_scores = decoder_out.output_scores

        # execute the decoder
        # 由于需要适配ctc_loss函数，返回的output.shape=T x B x C
        # 所以先变为B x T x C
        # 并且这里选择直接将normalize设置为True，即直接进行log_softmax操作
        _scores, _tokens = self.decoder(
            upsample_x=upsample_x,
            upsample_mask=upsample_mask,
            normalize=True
        ).transpose(0, 1).max(-1)
        # _scores = _scores.Long() # fix with masked_scatter_

        # greedy decoding
        output_masks = output_tokens.ne(self.pad).fill_(False)
        for i, sentence in enumerate(_tokens):
            prev_token = None
            for j, token in enumerate(sentence):
                if token == self.blank_idx:
                    prev_token = None
                elif prev_token == None:
                    prev_token = token
                    output_masks[i][j] = True
                elif token == prev_token:
                    continue
                else:
                    output_masks[i][j] = True
                    prev_token = token
        output_tokens.masked_scatter_(output_masks, _tokens[output_masks])
        output_scores.masked_scatter_(output_masks, _scores[output_masks])

        return decoder_out._replace(
            output_tokens=output_tokens,
            output_scores=output_scores,
            attn=None,
            history=history,
        )

    def get_normalized_probs_scriptable(
            self,
            net_output,
            log_probs: bool,
            sample
    ):
        """Get normalized probabilities (or log probs) from a net's output."""
        logits = net_output
        if log_probs:
            return utils.log_softmax(logits, dim=-1)
        else:
            return utils.softmax(logits, dim=-1)


class NAT_ctc_encoder(FairseqEncoder):
    def __init__(self, args, dictionary, embed_tokens):
        super().__init__(dictionary)
        self.dropout_module = FairseqDropout(
            args.dropout, module_name=self.__class__.__name__
        )

        self.embed_tokens = embed_tokens
        self.padding_idx = embed_tokens.padding_idx
        embed_dim = embed_tokens.embedding_dim
        self.padding_idx = embed_tokens.padding_idx

        self.embed_scale = 1.0 if args.no_scale_embedding else math.sqrt(embed_dim)

        self.scale = args.upsample_scale
        self.Linear = nn.Linear(embed_dim, embed_dim * self.scale)
        self.embed_positions = (
            PositionalEmbedding(
                args.max_source_positions,
                embed_dim,
                self.padding_idx,
                learned=args.encoder_learned_pos,
            )
            if not args.no_token_positional_embeddings
            else None
        )
        if getattr(args, "layernorm_embedding", False):
            self.layernorm_embedding = LayerNorm(embed_dim)
        else:
            self.layernorm_embedding = None


    def forward_embedding(
        self, src_tokens, token_embedding: Optional[torch.Tensor] = None
    ):
        # embed tokens and positions
        if token_embedding is None:
            token_embedding = self.embed_tokens(src_tokens)
        x = embed = self.embed_scale * token_embedding
        if self.embed_positions is not None:
            x = embed + self.embed_positions(src_tokens)
        if self.layernorm_embedding is not None:
            x = self.layernorm_embedding(x)
        x = self.dropout_module(x)
        # if self.quant_noise is not None:
        #     x = self.quant_noise(x)
        return x, embed

    def forward(self, src_tokens, src_lengths, token_embeddings: Optional[torch.Tensor] = None):
        x, _ = self.forward_embedding(src_tokens, token_embeddings)
        (batch_size, sequence_length, embed_dim) = x.shape
        # compute padding mask
        encoder_padding_mask = src_tokens.eq(self.padding_idx)
        # umsample x
        x = self.Linear(x)
        # reshape x
        x = x.reshape(batch_size, sequence_length * self.scale, embed_dim)
        # upsample mask
        encoder_padding_mask = encoder_padding_mask.unsqueeze(-1).expand(-1, -1, self.scale)
        encoder_padding_mask = encoder_padding_mask.reshape(batch_size, -1)
        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        return x, encoder_padding_mask

    @torch.jit.export
    def reorder_encoder_out(self, encoder_out, new_order):
        """
        Reorder encoder output according to *new_order*.

        Args:
            encoder_out: output from the ``forward()`` method
            new_order (LongTensor): desired order

        Returns:
            *encoder_out* rearranged according to *new_order*
        """
        upsample_x, upsample_mask = encoder_out
        # new_encoder_out = [encoder_out["encoder_out"][0].index_select(1, new_order)]
        new_upsample_x = upsample_x.index_select(1, new_order)
        new_upsample_mask = upsample_mask.index_select(1, new_order)

        return new_upsample_x, new_upsample_mask


class NAT_ctc_decoder(FairseqIncrementalDecoder):
    def __init__(self, args, dictionary, embed_tokens):
        super().__init__(dictionary)
        self.encoder_layerdrop = args.encoder_layerdrop
        if self.encoder_layerdrop > 0.0:
            self.layers = LayerDropModuleList(p=self.encoder_layerdrop)
        else:
            self.layers = nn.ModuleList([])
        self.layers.extend(
            [self.build_decoder_layer(args) for i in range(args.encoder_layers)]
        )
        self.output_embed_dim = embed_tokens.embedding_dim
        self.output_projection = nn.Linear(
            self.output_embed_dim, len(dictionary), bias=False
        )
        nn.init.normal_(
            self.output_projection.weight, mean=0, std=self.output_embed_dim ** -0.5
        )
        if args.encoder_normalize_before:
            self.layer_norm = LayerNorm(embed_dim)
        else:
            self.layer_norm = None

    def build_decoder_layer(self, args):
        layer = TransformerEncoderLayer(args)
        if getattr(args, "checkpoint_activations", False):
            offload_to_cpu = getattr(args, "offload_activations", False)
            layer = checkpoint_wrapper(layer, offload_to_cpu=offload_to_cpu)
        return layer

    def output_layer(self, features, **kwargs):
        """Project features to the vocabulary size."""
        return self.output_projection(features)

    def forward(self, upsample_x, upsample_mask, normalize: bool = False, features_only: bool = False):
        features = self.extract_features(
            upsample_x,
            upsample_mask
        )
        # 在Multi-task Learning中，需要output作为at decoder的encode_output，
        # 所以要求的shape是T x B x C，如果不加features_only参数，那么返回的就会是
        # 下面的T x B x Vocab
        if features_only:
            return features
        # 因为在upsample_ctc_loss中要求返回的output的shape是T x B x Vocab
        decoder_out = self.output_layer(features)
        return F.log_softmax(decoder_out, -1) if normalize else decoder_out

    def extract_features(self, upsample_x, upsample_mask):
        x = upsample_x
        for layer in self.layers:
            x = layer(x, upsample_mask)

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        # T x B x C -> B x T x C
        # x = x.transpose(0, 1)
        # return {
            # "encoder_out": [x],  # T x B x C
            # "upsample_mask": [upsample_mask],  # B x T
            # "encoder_embedding": [encoder_embedding],  # B x T x C
            # "src_tokens": [],
            # "src_lengths": [],
        # }
        """
        x.shape = T x B x C
        为了进入upsample_ctc_loss之后调用F.ctc_loss
        F.ctc_loss要求x的shape是T x B x C
        """
        return x


@register_model_architecture("nat_ctc", "nat_ctc_base")
def base_architecture(args):
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 12)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.upsample_scale =  getattr(args, "upsample_scale", 3)


    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", False)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.no_cross_attention = getattr(args, "no_cross_attention", False)
    args.cross_self_attention = getattr(args, "cross_self_attention", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    args.tie_adaptive_weights = getattr(args, "tie_adaptive_weights", False)
    args.checkpoint_activations = getattr(args, "checkpoint_activations", False)
    args.offload_activations = getattr(args, "offload_activations", False)
    if args.offload_activations:
        args.checkpoint_activations = True
    args.encoder_layers_to_keep = getattr(args, "encoder_layers_to_keep", None)
    args.decoder_layers_to_keep = getattr(args, "decoder_layers_to_keep", None)
    args.encoder_layerdrop = getattr(args, "encoder_layerdrop", 0)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.quant_noise_pq_block_size = getattr(args, "quant_noise_pq_block_size", 8)
    args.quant_noise_scalar = getattr(args, "quant_noise_scalar", 0)