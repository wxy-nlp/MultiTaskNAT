import torch
import torch.nn.functional as F
from fairseq import utils
from fairseq.iterative_refinement_generator import DecoderOut
from fairseq.models import register_model, register_model_architecture
from fairseq.models.nat import FairseqNATDecoder, FairseqNATModel, ensemble_decoder
from fairseq.models.transformer import Embedding, TransformerDecoder, TransformerModel
from fairseq.models.nat.nonautoregressive_transformer import NATransformerModel, NATransformerDecoder
from fairseq.models.nat.nat_ctc_encoder_only import NAT_ctc_encoder_only_model, NAT_ctc_encoder_only_decoder
from fairseq.models.fairseq_incremental_decoder import FairseqIncrementalDecoder

"""
This file implements:
"Multi-Task Learning with Shared Encoder for Non-Autoregressive Machine Translation".
A difference between ours and the paper is that our NAT model is 
the original NAT model(Gu, etc, 2017)
"""


class hybrid_decoder(NAT_ctc_encoder_only_decoder):
    def __init__(self, args, dictionary, embed_tokens, at_decoder, nat_decoder=None):
        super().__init__(args, dictionary, embed_tokens)
        self.at_decoder = at_decoder
        # self.nat_decoder = nat_decoder


@register_model("mt_ctc_encoder_only_model")
class nat_ctc_mt_model(NAT_ctc_encoder_only_model):
    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        # nat_decoder = NATransformerModel.build_decoder(args, tgt_dict, embed_tokens)
        at_decoder = TransformerModel.build_decoder(args, tgt_dict, embed_tokens)
        return hybrid_decoder(args, tgt_dict, embed_tokens, at_decoder)

    def forward(self, at_src_tokens, nat_src_tokens, src_lengths, prev_nat, prev_at, tgt_tokens, **kwargs):
        # upsampling
        # contain upsample_x and upsample_mask
        nat_upsample_x, nat_upsample_mask = self.encoder(nat_src_tokens, src_lengths=src_lengths, **kwargs)
        at_upsample_x, at_upsample_mask = self.encoder(at_src_tokens, src_lengths=src_lengths, **kwargs)

        # NAT decoding
        nat_decode_output = self.decoder(nat_upsample_x, nat_upsample_mask,
                                         normalize=False,
                                         features_only=False)

        # AT deep encoding
        at_encode_output = self.decoder(at_upsample_x, at_upsample_mask,
                                        normalize=False,
                                        features_only=True)
        at_encode_output = {
            "encoder_out": [at_encode_output],
            "encoder_padding_mask": [at_upsample_mask]
        }

        # AT shallow decoding
        at_decode_output, _ = self.decoder.at_decoder(prev_at,
                                                      encoder_out=at_encode_output,
                                                      features_only=False,
                                                      return_all_hiddens=True)

        return ({
                    "out": nat_decode_output, # T x B x C
                    "name": "NAT"
                },
                {
                    "out": at_decode_output, # B x T x C
                    "name": "AT"
                }
        )


@register_model_architecture("mt_ctc_model", "mt_ctc_model")
def base_architecture(args):
    # This is actually nat_ctc_decoder.
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 12)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.upsample_scale = getattr(args, "upsample_scale", 3)

    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 1)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", False)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.no_cross_attention = getattr(args, "no_cross_attention", False)
    args.cross_self_attention = getattr(args, "cross_self_attention", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    args.tie_adaptive_weights = getattr(args, "tie_adaptive_weights", False)
    args.checkpoint_activations = getattr(args, "checkpoint_activations", False)
    args.offload_activations = getattr(args, "offload_activations", False)
    if args.offload_activations:
        args.checkpoint_activations = True
    args.encoder_layers_to_keep = getattr(args, "encoder_layers_to_keep", None)
    args.decoder_layers_to_keep = getattr(args, "decoder_layers_to_keep", None)
    args.encoder_layerdrop = getattr(args, "encoder_layerdrop", 0)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.quant_noise_pq_block_size = getattr(args, "quant_noise_pq_block_size", 8)
    args.quant_noise_scalar = getattr(args, "quant_noise_scalar", 0)
