import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from fairseq import utils
from fairseq.iterative_refinement_generator import DecoderOut
from fairseq.models import register_model, register_model_architecture
from fairseq.models.fairseq_encoder import FairseqEncoder
from fairseq.models.fairseq_decoder import FairseqDecoder
from fairseq.models.nat import FairseqNATDecoder, FairseqNATModel, FairseqNATEncoder, ensemble_decoder
from fairseq.models.transformer import Embedding, TransformerDecoder, TransformerModel, TransformerEncoder
from fairseq.models.nat.nonautoregressive_transformer import NATransformerModel, NATransformerDecoder
from fairseq.modules.transformer_layer import TransformerEncoderLayer
from fairseq.models.fairseq_incremental_decoder import FairseqIncrementalDecoder
from typing import Any, Dict, List, Optional, Tuple
from fairseq.modules import (
    AdaptiveSoftmax,
    FairseqDropout,
    LayerDropModuleList,
    LayerNorm,
    PositionalEmbedding,
    SinusoidalPositionalEmbedding,
    TransformerDecoderLayer,
    TransformerEncoderLayer,
)


# 为了使用Transformer的build_model, get_normalized_probs,
# 再加上本身属于NAT model, 所以选择FairseqNATModel为父类
@register_model("nat_ctc_6_up_6")
class NAT_ctc_6_up_6_model(FairseqNATModel):
    def __init__(self, args, encoder, decoder):
        super().__init__(args, encoder, decoder)
        self.scale = args.upsample_scale
        self.blank_idx = decoder.dictionary.blank_index

    @staticmethod
    def add_args(parser):
        FairseqNATModel.add_args(parser)
        parser.add_argument("--upsample-scale", type=int, metavar='N',
                            help="the upsample scale of src-token-embedding.")
        parser.add_argument("--ctcdecoder-positional-embedding", default=False, action='store_true',
                            help='if set, ables ctc decoder\'s positional embeddings (outside self attention)')


    @classmethod
    def build_encoder(cls, args, src_dict, encoder_embed_tokens):
        """
        The encoder implements upsampling.
        """
        return NAT_ctc_encoder(args, src_dict, encoder_embed_tokens)

    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        """
        The decoder is actually TransformerEncoder.
        """
        return NAT_ctc_decoder(args, tgt_dict, embed_tokens)

    def forward(self, src_tokens, src_lengths, prev_output_tokens):
        encoder_out = self.encoder(src_tokens, src_lengths)
        output = self.decoder(encoder_out, prev_output_tokens, normalize=False)
        return output

    '''
    def initialize_output_tokens(self, encoder_out, src_tokens):
        # 不能像之前一样简单粗暴地用unk，因为本模型没有encoder，
        # 所以应该要把待翻译的src句子embed+upsample之后的结果返回
        # encoder_out为(upsample_x, upsample_mask)
        initial_output_tokens = src_tokens.unsqueeze(-1).expand(-1, -1, self.scale).reshape(batch_size, -1)
        initial_output_scores = initial_output_tokens.new_zeros(
            *initial_output_tokens.size()
        ).type_as(initial_output_tokens)
        
        # We just use encoder_out at forward_decoder and dont use output_tokens and output_scores.
        # Usually use encoder_out to predict length, and create initial_output_tokens
        # with length predicted. but in NAT_CTC model we dont need to predict length, 
        # so we write this function just for matching iterative_refinement_generator.
        return DecoderOut(
            output_tokens=initial_output_tokens,
            output_scores=initial_output_scores,
            attn=None,
            step=0,
            max_step=0,
            history=None,
        )
    '''

    def initialize_output_tokens(self, encoder_out, src_tokens):
        upsample_x = encoder_out["upsample_x"]
        initial_output_tokens = src_tokens.new_zeros(
            src_tokens.size(0), src_tokens.size(1) * self.scale
        ).fill_(self.pad)
        initial_output_scores = initial_output_tokens.new_zeros(
            *initial_output_tokens.size()
        ).type_as(upsample_x)
        return DecoderOut(
            output_tokens=initial_output_tokens,
            output_scores=initial_output_scores,
            attn=None,
            step=0,
            max_step=0,
            history=None,
        )

    '''
    def forward_decoder(self, decoder_out, encoder_out, **kwargs):
        # 包含了upsample_x和upsample_mask
        upsample_x, upsample_mask = encoder_out
        step = decoder_out.step
        history = decoder_out.history

        # execute the decoder
        # 由于需要适配ctc_loss函数，返回的output.shape=T x B x C
        # 所以先变为B x T x C
        # 并且这里选择直接将normalize设置为True，即直接进行log_softmax操作
        _scores, _tokens = self.decoder(
            upsample_x=upsample_x,
            upsample_mask=upsample_mask,
            normalize=True
        ).transpose(0, 1).max(-1)

        # greedy decoding
        max_length = _tokens.size(-1)
        outputs = []
        scores = []
        for i, sentence in enumerate(_tokens):
            idx = [False] * max_length
            prev_token = None
            for j, token in enumerate(sentence):
                if token == self.blank_idx:
                    prev_token = None
                elif prev_token == None:
                    prev_token = token
                    idx[j] = True
                elif token == prev_token:
                    continue
                else:
                    idx[j] = True
                    prev_token = token
            output = sentence[idx].tolist()
            score = _scores[i][idx].tolist()
            token_pad_list = [self.pad] * (max_length - len(output))
            score_pad_list = [0.0] * (max_length - len(output))
            output = torch.tensor(output + token_pad_list).type_as(_tokens).unsqueeze(0)
            score = torch.tensor(score + score_pad_list).type_as(_scores).unsqueeze(0)
            if i == 0:
                outputs = output
                scores = score
            else:
                outputs = torch.cat((outputs, output), dim=0)
                scores = torch.cat((scores, score), dim=0)

        return decoder_out._replace(
            output_tokens=outputs,
            output_scores=scores,
            attn=None,
            history=history,
        )
    '''

    def forward_decoder(self, decoder_out, encoder_out, **kwargs):
        # 包含了upsample_x和upsample_mask
        history = decoder_out.history
        output_tokens = decoder_out.output_tokens
        output_tokens_fill_unk = output_tokens.new_zeros(
            output_tokens.size(0), output_tokens.size(1)
        ).fill_(self.unk)
        output_scores = decoder_out.output_scores

        # execute the decoder
        # 由于需要适配ctc_loss函数，返回的output.shape=T x B x C
        # 所以先变为B x T x C
        # 并且这里选择直接将normalize设置为True，即直接进行log_softmax操作
        _scores, _tokens = self.decoder(
            encoder_out=encoder_out,
            prev_output_tokens=output_tokens_fill_unk,
            normalize=True
        ).transpose(0, 1).max(-1)

        # greedy decoding
        output_masks = output_tokens.ne(self.pad).fill_(False)
        for i, sentence in enumerate(_tokens):
            prev_token = None
            for j, token in enumerate(sentence):
                if token == self.blank_idx:
                    prev_token = None
                elif prev_token == None:
                    prev_token = token
                    output_masks[i][j] = True
                elif token == prev_token:
                    continue
                else:
                    output_masks[i][j] = True
                    prev_token = token
        output_tokens.masked_scatter_(output_masks, _tokens[output_masks])
        output_scores.masked_scatter_(output_masks, _scores[output_masks])

        return decoder_out._replace(
            output_tokens=output_tokens,
            output_scores=output_scores,
            attn=None,
            history=history,
        )

    def get_normalized_probs_scriptable(
            self,
            net_output,
            log_probs: bool,
            sample
    ):
        """Get normalized probabilities (or log probs) from a net's output."""
        logits = net_output
        if log_probs:
            return utils.log_softmax(logits, dim=-1)
        else:
            return utils.softmax(logits, dim=-1)


class NAT_ctc_encoder(FairseqNATEncoder):
    def __init__(self, args, dictionary, embed_tokens):
        super().__init__(args, dictionary, embed_tokens)
        embed_dim = embed_tokens.embedding_dim
        self.scale = args.upsample_scale
        self.upsample_Linear = nn.Linear(embed_dim, self.scale * embed_dim)


    def forward(self, src_tokens, src_lengths, token_embeddings: Optional[torch.Tensor] = None):
        # compute padding mask
        encoder_padding_mask = src_tokens.eq(self.padding_idx)
        has_pads = (src_tokens.device.type == "xla" or encoder_padding_mask.any())

        x, encoder_embedding = self.forward_embedding(src_tokens, token_embeddings)

        # account for padding while computing the representation
        # if encoder_padding_mask is not None:
        #     x = x * (1 - encoder_padding_mask.unsqueeze(-1).type_as(x))

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        # encoder layers
        for layer in self.layers:
            x = layer(
                x, encoder_padding_mask=encoder_padding_mask if has_pads else None
            )

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        # umsample x
        (sequence_length, batch_size, embed_dim) = x.shape
        upsample_x = x.transpose(0, 1) # B x T x C
        upsample_x = self.upsample_Linear(upsample_x)
        # reshape x: B x upsample_scale*T x C
        upsample_x = upsample_x.reshape(batch_size, sequence_length * self.scale, embed_dim)
        # upsample mask
        upsample_mask = encoder_padding_mask.unsqueeze(-1).expand(-1, -1, self.scale)
        upsample_mask = upsample_mask.reshape(batch_size, -1)

        # The Pytorch Mobile lite interpreter does not supports returning NamedTuple in
        # `forward` so we use a dictionary instead.
        # TorchScript does not support mixed values so the values are all lists.
        # The empty list is equivalent to None.
        return {
            "encoder_out": [x],  # T x B x C
            "encoder_padding_mask": [encoder_padding_mask],  # B x T
            # "encoder_embedding": [encoder_embedding],  # B x T x C
            # "encoder_states": encoder_states,  # List[T x B x C]
            # "src_tokens": [],
            # "src_lengths": [],
            "upsample_x": upsample_x, # B x upsample_scale*T x C
            "upsample_mask": upsample_mask # B x upsample_scale*T
        }


class NAT_ctc_decoder(FairseqNATDecoder):
    def __init__(self, args, dictionary, embed_tokens):
        super().__init__(args, dictionary, embed_tokens)
        if not args.ctcdecoder_positional_embedding:
            self.embed_positions = None

    def output_layer(self, features, **kwargs):
        """Project features to the vocabulary size."""
        return self.output_projection(features)

    def forward(self, encoder_out, prev_output_tokens, normalize: bool = False, features_only: bool = False):
        """
        prev_output_tokens: (bsz, src_len*upsample_scale) with all unk
        the prev_output_tokens only helps ctc decoder's positional embedding
        you can use it with setting args.ctcdecoder_positional_embeddings True.
        """
        features = self.extract_features(
            encoder_out=encoder_out,
            prev_output_tokens=prev_output_tokens
        )
        if features_only: # used for mt_ctc_6_up_6
            return features
        decoder_out = self.output_layer(features)
        return F.log_softmax(decoder_out, -1) if normalize else decoder_out

    def extract_features(self, encoder_out, prev_output_tokens, incremental_state=None):
        # embed positions
        positions = None
        if self.embed_positions is not None:
            positions = self.embed_positions(
                prev_output_tokens, incremental_state=incremental_state
            )

        # embed tokens and positions
        x = encoder_out["upsample_x"] # B x self.scale*T x C
        self_attn_padding_mask = encoder_out["upsample_mask"]

        if self.quant_noise is not None:
            x = self.quant_noise(x)

        if self.project_in_dim is not None:
            x = self.project_in_dim(x)

        if positions is not None:
            x += positions

        if self.layernorm_embedding is not None:
            x = self.layernorm_embedding(x)

        x = self.dropout_module(x)

        # B x T x C -> T x B x C
        x = x.transpose(0, 1)

        # decoder layers
        # attn: Optional[Tensor] = None
        # inner_states: List[Optional[Tensor]] = [x]
        for idx, layer in enumerate(self.layers):
            x, layer_attn, _ = layer(
                x,
                encoder_out["encoder_out"][0]
                if (encoder_out is not None and len(encoder_out["encoder_out"]) > 0)
                else None,
                encoder_out["encoder_padding_mask"][0]
                if (
                    encoder_out is not None
                    and len(encoder_out["encoder_padding_mask"]) > 0
                )
                else None,
                self_attn_mask=None,
                self_attn_padding_mask=self_attn_padding_mask,
            )
            # inner_states.append(x)

        if self.layer_norm is not None:
            x = self.layer_norm(x)

        if self.project_out_dim is not None:
            x = self.project_out_dim(x)

        """
        x.shape = T x B x C
        为了进入upsample_ctc_loss之后调用F.ctc_loss
        F.ctc_loss要求x的shape是T x B x C
        """
        return x


@register_model_architecture("nat_ctc_6_up_6", "nat_ctc_6_up_6")
def base_architecture(args):
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 6)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.upsample_scale =  getattr(args, "upsample_scale", 3)


    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", False)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.no_cross_attention = getattr(args, "no_cross_attention", False)
    args.cross_self_attention = getattr(args, "cross_self_attention", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    args.no_scale_embedding = getattr(args, "no_scale_embedding", False)
    args.layernorm_embedding = getattr(args, "layernorm_embedding", False)
    args.tie_adaptive_weights = getattr(args, "tie_adaptive_weights", False)
    args.checkpoint_activations = getattr(args, "checkpoint_activations", False)
    args.offload_activations = getattr(args, "offload_activations", False)
    if args.offload_activations:
        args.checkpoint_activations = True
    args.encoder_layers_to_keep = getattr(args, "encoder_layers_to_keep", None)
    args.decoder_layers_to_keep = getattr(args, "decoder_layers_to_keep", None)
    args.encoder_layerdrop = getattr(args, "encoder_layerdrop", 0)
    args.decoder_layerdrop = getattr(args, "decoder_layerdrop", 0)
    args.quant_noise_pq = getattr(args, "quant_noise_pq", 0)
    args.quant_noise_pq_block_size = getattr(args, "quant_noise_pq_block_size", 8)
    args.quant_noise_scalar = getattr(args, "quant_noise_scalar", 0)