import torch
import torch.nn.functional as F
from fairseq import utils
from fairseq.iterative_refinement_generator import DecoderOut
from fairseq.models import register_model, register_model_architecture
from fairseq.models.nat import FairseqNATDecoder, FairseqNATModel, ensemble_decoder
from fairseq.models.transformer import Embedding, TransformerDecoder, TransformerModel
from fairseq.models.nat.nonautoregressive_transformer import NATransformerModel, NATransformerDecoder
from fairseq.models.nat.cmlm_transformer import CMLMNATransformerModel
from fairseq.models.fairseq_incremental_decoder import FairseqIncrementalDecoder

"""
This file implements:
"Multi-Task Learning with Shared Encoder for Non-Autoregressive Machine Translation".
A difference between ours and the paper is that our NAT model is 
the original NAT model(Gu, etc, 2017)
"""


class hybrid_decoder(NATransformerDecoder):
    def __init__(self, args, dictionary, embed_tokens, at_decoder, nat_decoder=None):
        super().__init__(args, dictionary, embed_tokens)
        self.at_decoder = at_decoder
        # self.nat_decoder = nat_decoder


@register_model("wxy_warmup_model_test")
class hybrid_nat_at_model(CMLMNATransformerModel):
    @classmethod
    def build_decoder(cls, args, tgt_dict, embed_tokens):
        # nat_decoder = NATransformerModel.build_decoder(args, tgt_dict, embed_tokens)
        at_decoder = TransformerModel.build_decoder(args, tgt_dict, embed_tokens)
        return hybrid_decoder(args, tgt_dict, embed_tokens, at_decoder)

    def forward(self, at_src_tokens, nat_src_tokens, src_lengths, prev_nat, prev_at, tgt_tokens, **kwargs):
        # encoding
        at_encode_output = self.encoder(at_src_tokens, src_lengths=src_lengths, **kwargs)
        nat_encode_output = self.encoder(nat_src_tokens, src_lengths=src_lengths, **kwargs)

        # length prediction
        length_out = self.decoder.forward_length(
            normalize=False, encoder_out=nat_encode_output
        )
        length_tgt = self.decoder.forward_length_prediction(
            length_out, nat_encode_output, tgt_tokens
        )

        # AT decoding
        at_decode_output, _ = self.decoder.at_decoder(prev_at,
                                                   encoder_out=at_encode_output,
                                                   src_lengths=src_lengths,
                                                   features_only=False,
                                                   return_all_hiddens=True)
        # NAT decoding
        nat_decode_output = self.decoder(normalize=False,
                                                     prev_output_tokens=prev_nat,
                                                     encoder_out=nat_encode_output)

        word_ins_mask = prev_nat.eq(self.unk)

        return ({
            "word_ins": {
                "out": nat_decode_output,
                "tgt": tgt_tokens,
                # "mask": tgt_tokens.ne(self.pad),
                "mask": word_ins_mask,
                "ls": self.args.label_smoothing,
                "nll_loss": True,
                },
            "length": {
                "out": length_out,
                "tgt": length_tgt,
                "factor": self.decoder.length_loss_factor,
            },
            "name": "NAT"
        } ,
        {
            "word_ins": {
                "out": at_decode_output,
                "tgt": tgt_tokens,
                "ls": self.args.label_smoothing,
                "mask": tgt_tokens.ne(self.pad),
                "nll_loss": True
            },
            "name": "AT"
        }
        )


@register_model_architecture("wxy_warmup_model_test", "wxy_warmup_model_test_base")
def hybrid_base_architecture(args):
    args.encoder_embed_path = getattr(args, "encoder_embed_path", None)
    args.encoder_embed_dim = getattr(args, "encoder_embed_dim", 512)
    args.encoder_ffn_embed_dim = getattr(args, "encoder_ffn_embed_dim", 2048)
    args.encoder_layers = getattr(args, "encoder_layers", 6)
    args.encoder_attention_heads = getattr(args, "encoder_attention_heads", 8)
    args.encoder_normalize_before = getattr(args, "encoder_normalize_before", False)
    args.encoder_learned_pos = getattr(args, "encoder_learned_pos", False)
    args.decoder_embed_path = getattr(args, "decoder_embed_path", None)
    args.decoder_embed_dim = getattr(args, "decoder_embed_dim", args.encoder_embed_dim)
    args.decoder_ffn_embed_dim = getattr(
        args, "decoder_ffn_embed_dim", args.encoder_ffn_embed_dim
    )
    args.decoder_layers = getattr(args, "decoder_layers", 6)
    args.decoder_attention_heads = getattr(args, "decoder_attention_heads", 8)
    args.decoder_normalize_before = getattr(args, "decoder_normalize_before", False)
    args.decoder_learned_pos = getattr(args, "decoder_learned_pos", False)
    args.attention_dropout = getattr(args, "attention_dropout", 0.0)
    args.activation_dropout = getattr(args, "activation_dropout", 0.0)
    args.activation_fn = getattr(args, "activation_fn", "relu")
    args.dropout = getattr(args, "dropout", 0.1)
    args.adaptive_softmax_cutoff = getattr(args, "adaptive_softmax_cutoff", None)
    args.adaptive_softmax_dropout = getattr(args, "adaptive_softmax_dropout", 0)
    args.share_decoder_input_output_embed = getattr(
        args, "share_decoder_input_output_embed", False
    )
    args.share_all_embeddings = getattr(args, "share_all_embeddings", True)
    args.no_token_positional_embeddings = getattr(
        args, "no_token_positional_embeddings", False
    )
    args.adaptive_input = getattr(args, "adaptive_input", False)
    args.apply_bert_init = getattr(args, "apply_bert_init", False)

    args.decoder_output_dim = getattr(
        args, "decoder_output_dim", args.decoder_embed_dim
    )
    args.decoder_input_dim = getattr(args, "decoder_input_dim", args.decoder_embed_dim)

    # --- special arguments ---
    args.sg_length_pred = getattr(args, "sg_length_pred", False)
    args.pred_length_offset = getattr(args, "pred_length_offset", False)
    args.length_loss_factor = getattr(args, "length_loss_factor", 0.1)
    args.ngram_predictor = getattr(args, "ngram_predictor", 1)
    args.src_embedding_copy = getattr(args, "src_embedding_copy", False)