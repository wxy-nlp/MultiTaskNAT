import torch
import torch.nn.functional as F
from fairseq import metrics, utils
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.criterions.nat_loss import LabelSmoothedDualImitationCriterion
from fairseq.criterions.label_smoothed_cross_entropy import label_smoothed_nll_loss


@register_criterion("wxy_warmup_loss")
class hybrid_nat_at_loss(LabelSmoothedDualImitationCriterion):
    def __init__(self, task, lambda_nat_at, label_smoothing):
        super().__init__(task, label_smoothing)
        self.lambda_nat_at = lambda_nat_at

    @staticmethod
    def add_args(parser):
        """Add criterion-specific arguments to the parser."""
        parser.add_argument(
            "--lambda_nat_at",
            default=0.5,
            type=float,
        )
        parser.add_argument(
            "--label-smoothing",
            default=0.0,
            type=float,
            metavar="D",
            help="epsilon for label smoothing, 0 means no label smoothing",
        )
        parser.add_argument(
            '--at-drop-rate', type=float, default=0.5)
        parser.add_argument(
            '--nat-drop-rate', type=float, default=0.0)

    def forward(self, model, sample, reduce=True):
        """
        Compute the loss of Multi-task learning.
        Loss = \lambda Loss_{at} + (1 - \lambda) Loss_{nat}
        Returns a tuple with three elements:
        1) the loss
        2) the sample size, which is used as the denominator for the gradient
        3) logging outputs to display while training
        """

        nsentences, ntokens = sample["nsentences"], sample["ntokens"]

        # B x T
        src_tokens, src_lengths = (
            sample["net_input"]["src_tokens"],
            sample["net_input"]["src_lengths"],
        )
        tgt_tokens, prev_nat, prev_at = sample["target"], \
                                        sample["prev_target"], \
                                        sample["net_input"]["prev_output_tokens"]

        # TODO 根据model的forward函数来决定这里传什么参数

        hybrid_outputs = model(src_tokens, src_lengths, prev_nat, prev_at, tgt_tokens)
        hybrid_loss, hybrid_nll_loss = {}, {}

        for outputs in hybrid_outputs:
            losses, nll_loss = [], []
            for obj in outputs:
                if isinstance(outputs[obj], dict) is False:
                    break
                if outputs[obj].get("loss", None) is None:
                    _losses = self._compute_loss(
                        outputs[obj].get("out"),
                        outputs[obj].get("tgt"),
                        outputs[obj].get("mask", None),
                        outputs[obj].get("ls", 0.0),
                        name=obj + "-loss",
                        factor=outputs[obj].get("factor", 1.0),
                    )
                else:
                    _losses = self._custom_loss(
                        outputs[obj].get("loss"),
                        name=obj + "-loss",
                        factor=outputs[obj].get("factor", 1.0),
                    )

                losses += [_losses]
                if outputs[obj].get("nll_loss", False):
                    nll_loss += [_losses.get("nll_loss", 0.0)]


            tmp_loss = sum(l["loss"] for l in losses)
            tmp_nll_loss = sum(l for l in nll_loss) if len(nll_loss) > 0 else loss.new_tensor(0)
            #TODO 怎么写choices?
            assert outputs.get("name") is not None
            if outputs.get("name") == "NAT":
                hybrid_loss["NAT"] = tmp_loss
                hybrid_nll_loss["NAT"] = tmp_nll_loss
            elif outputs.get("name") == "AT":
                hybrid_loss["AT"] = tmp_loss
                hybrid_nll_loss["AT"] = tmp_nll_loss


        loss = self.lambda_nat_at * hybrid_loss["AT"] + \
            (1 - self.lambda_nat_at) * hybrid_loss["NAT"]
        nll_loss = self.lambda_nat_at * hybrid_nll_loss["AT"] + \
            (1 - self.lambda_nat_at) * hybrid_nll_loss["NAT"]

        # NOTE:
        # we don't need to use sample_size as denominator for the gradient
        # here sample_size is just used for logging
        sample_size = 1
        logging_output = {
            "loss": loss.data,
            "nll_loss": nll_loss.data,
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": sample_size,
        }

        for l in losses:
            logging_output[l["name"]] = (
                utils.item(l["loss"].data / l["factor"])
                if reduce
                else l[["loss"]].data / l["factor"]
            )

        return loss, sample_size, logging_output
