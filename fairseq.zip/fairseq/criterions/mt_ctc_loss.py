import torch
import torch.nn.functional as F
from fairseq import metrics, utils
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.criterions.nat_loss import LabelSmoothedDualImitationCriterion
from fairseq.criterions.label_smoothed_cross_entropy import label_smoothed_nll_loss


@register_criterion("mt_ctc_loss")
class mt_ctc_loss(LabelSmoothedDualImitationCriterion):
    def __init__(self, task, lambda_nat_at, label_smoothing, zero_infinity):
        super().__init__(task, label_smoothing)
        self.lambda_nat_at = lambda_nat_at
        self.blank_idx = task.target_dictionary.blank_index
        self.upsample_scale = task.cfg.upsample_scale
        self.pad_idx = task.target_dictionary.pad()
        self.eos_idx = task.target_dictionary.eos()
        self.zero_infinity = zero_infinity

    @staticmethod
    def add_args(parser):
        """Add criterion-specific arguments to the parser."""
        parser.add_argument(
            "--lambda-nat-at",
            default=0.5,
            type=float,
        )
        parser.add_argument(
            "--label-smoothing",
            default=0.1,
            type=float,
            metavar="D",
            help="epsilon for label smoothing, 0 means no label smoothing",
        )
        parser.add_argument(
            '--at-drop-rate', type=float, default=0.5)
        parser.add_argument(
            '--nat-drop-rate', type=float, default=0.0)
        parser.add_argument(
            '--zero-infinity', type=bool, default=True)


    def forward(self, model, at_sample, nat_sample, reduce=True):
        """
        Compute the loss of Multi-task learning.
        Loss = \lambda Loss_{at} + (1 - \lambda) Loss_{nat}
        Returns a tuple with three elements:
        1) the loss
        2) the sample size, which is used as the denominator for the gradient
        3) logging outputs to display while training
        """

        def drop_sentences_(sample, rate, indexes=None):
            bsz = sample['nsentences']
            if indexes is None:
                indexes = gen_randperm(bsz, rate)
            nbsz = indexes.size(0)
            for k, v in sample['net_input'].items():
                if isinstance(v, torch.Tensor):
                    sample['net_input'][k] = v[indexes]
            for k, v in sample.items():
                if isinstance(v, torch.Tensor):
                    sample[k] = v[indexes]
            sample['ntokens'] = sample['ntokens'] * nbsz // bsz
            sample['nsentences'] = nbsz
            return sample

        def gen_randperm(bsz, droprate):
            nbsz = max(1, int((1.0 - droprate) * bsz))
            return torch.randperm(bsz)[:nbsz]

        nsentences, ntokens = at_sample["nsentences"], at_sample["ntokens"]

        at_sample = drop_sentences_(at_sample, 0)
        # B x T
        at_src_tokens, src_lengths, nat_src_tokens = (
            at_sample["net_input"]["src_tokens"],
            at_sample["net_input"]["src_lengths"],
            nat_sample["net_input"]["src_tokens"]
        )
        at_tgt_tokens, prev_nat, prev_at = at_sample["target"], \
                                        nat_sample["prev_target"], \
                                        at_sample["net_input"]["prev_output_tokens"]

        # TODO 根据model的forward函数来决定这里传什么参数

        hybrid_outputs = model(at_src_tokens, nat_src_tokens, src_lengths, prev_nat, prev_at, at_tgt_tokens)
        hybrid_loss = {}

        for outputs in hybrid_outputs:
            if outputs['name'] == "NAT":
                net_output = outputs['out']
                lprobs = model.get_normalized_probs(
                    net_output, log_probs=True
                ).contiguous()  # (T, B, C) from the decoder
                input_lengths = nat_sample["net_input"]["src_lengths"] * self.upsample_scale
                pad_mask = (nat_sample["target"] != self.pad_idx) & (
                        nat_sample["target"] != self.eos_idx
                )
                targets_flat = nat_sample["target"].masked_select(pad_mask)
                if "target_lengths" in nat_sample:
                    target_lengths = nat_sample["target_lengths"]
                else:
                    target_lengths = pad_mask.sum(-1)

                with torch.backends.cudnn.flags(enabled=False):
                    loss = F.ctc_loss(
                        lprobs.float(),  # to fix with fp16
                        targets_flat,
                        input_lengths,
                        target_lengths,
                        blank=self.blank_idx,
                        reduction="mean",
                        zero_infinity=self.zero_infinity,
                    )
                hybrid_loss["NAT"] = loss
        #         hybrid_nll_loss["NAT"] = 0
            elif outputs['name'] == "AT":
                at_net_outputs = outputs['out']
                at_loss_list, at_nll_loss_list = [], []
                for at_net_output in at_net_outputs:
                    at_lprobs = model.get_normalized_probs(at_net_output, log_probs=True)
                    at_target = model.get_targets(at_sample, at_net_output)

                    at_loss, at_nll_loss = label_smoothed_nll_loss(
                        at_lprobs.view(-1, at_lprobs.size(-1)), at_target.view(-1, 1), self.label_smoothing,
                        ignore_index=self.padding_idx,
                        reduce=reduce,
                    )
                    at_loss, at_nll_loss = at_loss.mean(), at_nll_loss.mean()
                    at_loss_list.append(at_loss)
                    at_nll_loss_list.append(at_nll_loss)
                hybrid_loss["AT"] = sum(l for l in at_loss_list) / len(at_loss_list)
        #         hybrid_nll_loss["AT"] = at_nll_loss
            else:
                raise NotImplementedError

        loss = self.lambda_nat_at * hybrid_loss["AT"] + \
            (1 - self.lambda_nat_at) * hybrid_loss["NAT"]
        # nll_loss = self.lambda_nat_at * hybrid_nll_loss["AT"] + \
        #     (1 - self.lambda_nat_at) * hybrid_nll_loss["NAT"]

        # NOTE:
        # we don't need to use sample_size as denominator for the gradient
        # here sample_size is just used for logging
        sample_size = 1
        logging_output = {
            "loss": loss.data,
            # "nll_loss": nll_loss.data,
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": sample_size,
            "nat_ctc_loss": hybrid_loss["NAT"],
            "at_loss": hybrid_loss["AT"]
        }

        return loss, sample_size, logging_output
