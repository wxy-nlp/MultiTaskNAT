import torch
import torch.nn.functional as F
from fairseq import metrics, utils
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.criterions.nat_loss import LabelSmoothedDualImitationCriterion
from fairseq.criterions.label_smoothed_cross_entropy import label_smoothed_nll_loss

def merge_dict(origin, new, prefix):
    for key, value in new.items():
        origin[prefix + key] = value
    return origin

@register_criterion("wxy_mt_loss")
class MultitaskLearningLoss(LabelSmoothedDualImitationCriterion):
    def __init__(self, cfg, task, label_smoothing):
        super().__init__(task, label_smoothing)
        self.cfg = cfg

    def loss_fn(self, at_loss, nat_loss, at_sample_size, nat_sample_size, batch_sample_size):
        return self.cfg.at_weight * at_loss / at_sample_size * batch_sample_size + \
               self.cfg.nat_weight * nat_loss

    @staticmethod
    def add_args(parser):
        LabelSmoothedDualImitationCriterion.add_args(parser)
        parser.add_argument(
            '--at-weight', type=float, default=0.5)
        parser.add_argument(
            '--nat-weight', type=float, default=0.5)
        parser.add_argument(
            '--at-drop-rate', type=float, default=0.5)
        parser.add_argument(
            '--nat-drop-rate', type=float, default=0.0)
        parser.add_argument(
            '--selection-criterion', type=str, default='nat')

    def forward(self, model, at_sample, nat_sample, reduce=True, steps=None):
        at_model = model.at_model
        nat_model = model.nat_model

        def gen_randperm(bsz, droprate):
            nbsz = max(1, int((1.0 - droprate) * bsz))
            return torch.randperm(bsz)[:nbsz]

        def drop_sentences_(sample, rate, indexes=None):
            bsz = sample['nsentences']
            if indexes is None:
                indexes = gen_randperm(bsz, rate)
            nbsz = indexes.size(0)
            for k, v in sample['net_input'].items():
                if isinstance(v, torch.Tensor):
                    sample['net_input'][k] = v[indexes]
            for k, v in sample.items():
                if isinstance(v, torch.Tensor):
                    sample[k] = v[indexes]
            sample['ntokens'] = sample['ntokens'] * nbsz // bsz
            sample['nsentences'] = nbsz
            return sample

        ntokens = at_sample['ntokens']
        nsentences = at_sample['nsentences']
        sample_size = nsentences if self.cfg.sentence_avg else ntokens
        """
        AT decoding.
        """
        at_sample = drop_sentences_(at_sample, self.cfg.at_drop_rate)
        at_src_tokens, at_src_lengths = at_sample['net_input']['src_tokens'], at_sample['net_input']['src_lengths']
        at_prev_output_tokens = at_sample['net_input']['prev_output_tokens']
        at_encoder_out = at_model.encoder(at_src_tokens, at_src_lengths)
        at_net_output = at_model.decoder(at_prev_output_tokens,
                                                   encoder_out=at_encoder_out,
                                                   src_lengths=at_src_lengths,
                                                   features_only=False,
                                                   return_all_hiddens=True)
        at_lprobs = at_model.get_normalized_probs(at_net_output, log_probs=True)
        at_target = at_model.get_targets(at_sample, at_net_output)

        at_loss, at_nll_loss = label_smoothed_nll_loss(
            at_lprobs.view(-1, at_lprobs.size(-1)), at_target.view(-1, 1), self.label_smoothing,
            ignore_index=self.padding_idx,
            reduce=reduce,
        )
        at_loss, at_nll_loss = at_loss.mean(), at_nll_loss.mean()
        at_sample_size = at_sample['target'].size(0) if self.cfg.sentence_avg else at_sample['ntokens']

        nat_src_tokens, nat_src_lengths = nat_sample['net_input']['src_tokens'], \
                                          nat_sample['net_input']['src_lengths']
        nat_encoder_out = nat_model.encoder(nat_src_tokens, nat_src_lengths)
        tgt_tokens, prev_output_tokens = nat_sample["target"], nat_sample["prev_target"]

        length_out = nat_model.decoder.forward_length(normalize=False,
                                                      encoder_out=nat_encoder_out)
        length_tgt = nat_model.decoder.forward_length_prediction(length_out,
                                                                 nat_encoder_out,
                                                                 tgt_tokens)
        word_ins_out = nat_model.decoder(
            normalize=False,
            prev_output_tokens=prev_output_tokens,
            encoder_out=nat_encoder_out)
        word_ins_mask = prev_output_tokens.eq(nat_model.unk)
        outputs = {
            "word_ins": {
                "out": word_ins_out, "tgt": tgt_tokens,
                "mask": word_ins_mask, "ls": self.label_smoothing,
                "nll_loss": True
            },
            "length": {
                "out": length_out, "tgt": length_tgt,
                "factor": nat_model.decoder.length_loss_factor
            }
        }
        losses, nll_losses = [], []
        for obj in outputs:
            if outputs[obj].get("loss", None) is None:
                _losses = self._compute_loss(
                    outputs[obj].get("out"),
                    outputs[obj].get("tgt"),
                    outputs[obj].get("mask", None),
                    outputs[obj].get("ls", 0.0),
                    name=obj + '-loss',
                    factor=outputs[obj].get("factor", 1.0)
                )
            else:
                assert False

            losses += [_losses]
            if outputs[obj].get("nll_loss", False):
                nll_losses += [_losses.get("nll_loss", 0.0)]

        nat_loss = sum(l["loss"] for l in losses)
        nat_nll_loss = sum(l for l in nll_losses) if len(nll_losses) > 0 \
            else loss.new_tensor(0)
        nat_nll_loss = nat_nll_loss

        # NOTE:
        # we don't need to use sample_size as denominator for the gradient
        # here sample_size is just used for logging
        nat_sample_size = 1

        loss = self.loss_fn(at_loss, nat_loss, at_sample_size, nat_sample_size,
                            sample_size)
        nll_loss = self.loss_fn(at_nll_loss, nat_nll_loss, at_sample_size, nat_sample_size,
                                sample_size)
        logging_output = {
            "loss": loss.data,
            "nll_loss": nll_loss.data,
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": nat_sample_size,
            "at_loss": at_loss,
            "nat_loss": nat_loss
        }
        for l in losses:
            logging_output[l["name"]] = (
                utils.item(l["loss"].data / l["factor"])
                if reduce
                else l["loss"].data / l["factor"]
            )
        logging_output['nat-weight'] = self.cfg.nat_weight
        logging_output['at-weight'] = self.cfg.at_weight

        return loss, sample_size, logging_output