import torch
import torch.nn.functional as F
from fairseq import metrics, utils
from fairseq.criterions import FairseqCriterion, register_criterion
from fairseq.criterions.nat_loss import LabelSmoothedDualImitationCriterion
from fairseq.criterions.label_smoothed_cross_entropy import label_smoothed_nll_loss


@register_criterion("mt_nat_loss")
class mt_nat_loss(LabelSmoothedDualImitationCriterion):
    def __init__(self, task, lambda_nat_at, label_smoothing):
        super().__init__(task, label_smoothing)
        self.lambda_nat_at = lambda_nat_at

    @staticmethod
    def add_args(parser):
        """Add criterion-specific arguments to the parser."""
        parser.add_argument(
            "--lambda_nat_at",
            default=0.5,
            type=float,
        )
        parser.add_argument(
            "--label-smoothing",
            default=0.1,
            type=float,
            metavar="D",
            help="epsilon for label smoothing, 0 means no label smoothing",
        )
        parser.add_argument(
            '--at-drop-rate', type=float, default=0.5)
        parser.add_argument(
            '--nat-drop-rate', type=float, default=0.0)

    def forward(self, model, at_sample, nat_sample, reduce=True):
        """
        Compute the loss of Multi-task learning.
        Loss = \lambda Loss_{at} + (1 - \lambda) Loss_{nat}
        Returns a tuple with three elements:
        1) the loss
        2) the sample size, which is used as the denominator for the gradient
        3) logging outputs to display while training
        """

        def drop_sentences_(sample, rate, indexes=None):
            bsz = sample['nsentences']
            if indexes is None:
                indexes = gen_randperm(bsz, rate)
            nbsz = indexes.size(0)
            for k, v in sample['net_input'].items():
                if isinstance(v, torch.Tensor):
                    sample['net_input'][k] = v[indexes]
            for k, v in sample.items():
                if isinstance(v, torch.Tensor):
                    sample[k] = v[indexes]
            sample['ntokens'] = sample['ntokens'] * nbsz // bsz
            sample['nsentences'] = nbsz
            return sample

        def gen_randperm(bsz, droprate):
            nbsz = max(1, int((1.0 - droprate) * bsz))
            return torch.randperm(bsz)[:nbsz]

        nsentences, ntokens = at_sample["nsentences"], at_sample["ntokens"]

        at_sample = drop_sentences_(at_sample, 0)
        # B x T
        at_src_tokens, src_lengths, nat_src_tokens = (
            at_sample["net_input"]["src_tokens"],
            at_sample["net_input"]["src_lengths"],
            nat_sample["net_input"]["src_tokens"]
        )
        tgt_tokens, prev_nat, prev_at = nat_sample["target"], \
                                        nat_sample["prev_target"], \
                                        at_sample["net_input"]["prev_output_tokens"]

        # TODO 根据model的forward函数来决定这里传什么参数

        hybrid_outputs = model(at_src_tokens, nat_src_tokens, src_lengths, prev_nat, prev_at, tgt_tokens)
        hybrid_loss, hybrid_nll_loss = {}, {}

        for outputs in hybrid_outputs:
            if outputs['name'] == "NAT":
                losses, nll_loss = [], []
                for obj in outputs:
                    if isinstance(outputs[obj], dict) is False:
                        break
                    if outputs[obj].get("loss", None) is None:
                        _losses = self._compute_loss(
                            outputs[obj].get("out"),
                            outputs[obj].get("tgt"),
                            outputs[obj].get("mask", None),
                            outputs[obj].get("ls", 0.0),
                            name=obj + "-loss",
                            factor=outputs[obj].get("factor", 1.0),
                        )
                    else:
                        _losses = self._custom_loss(
                            outputs[obj].get("loss"),
                            name=obj + "-loss",
                            factor=outputs[obj].get("factor", 1.0),
                        )

                    losses += [_losses]
                    if outputs[obj].get("nll_loss", False):
                        nll_loss += [_losses.get("nll_loss", 0.0)]

                tmp_loss = sum(l["loss"] for l in losses)
                tmp_nll_loss = sum(l for l in nll_loss) if len(nll_loss) > 0 else loss.new_tensor(0)
                hybrid_loss["NAT"] = tmp_loss
                hybrid_nll_loss["NAT"] = tmp_nll_loss
            elif outputs['name'] == "AT":
                at_net_output = outputs['out']
                at_lprobs = model.get_normalized_probs([at_net_output], log_probs=True)
                at_target = model.get_targets(at_sample, at_net_output)

                at_loss, at_nll_loss = label_smoothed_nll_loss(
                    at_lprobs.view(-1, at_lprobs.size(-1)), at_target.view(-1, 1), self.label_smoothing,
                    ignore_index=self.padding_idx,
                    reduce=reduce,
                )
                at_loss, at_nll_loss = at_loss.mean(), at_nll_loss.mean()
                hybrid_loss["AT"] = at_loss
                hybrid_nll_loss["AT"] = at_nll_loss
            else:
                raise NotImplementedError

        loss = self.lambda_nat_at * hybrid_loss["AT"] + \
            (1 - self.lambda_nat_at) * hybrid_loss["NAT"]
        nll_loss = self.lambda_nat_at * hybrid_nll_loss["AT"] + \
            (1 - self.lambda_nat_at) * hybrid_nll_loss["NAT"]

        # NOTE:
        # we don't need to use sample_size as denominator for the gradient
        # here sample_size is just used for logging
        sample_size = 1
        logging_output = {
            "loss": loss.data,
            "nll_loss": nll_loss.data,
            "ntokens": ntokens,
            "nsentences": nsentences,
            "sample_size": sample_size,
        }

        for l in losses:
            logging_output[l["name"]] = (
                utils.item(l["loss"].data / l["factor"])
                if reduce
                else l["loss"].data / l["factor"]
            )

        return loss, sample_size, logging_output
